import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { LogOut, User, Settings, Sparkles, BookText, Bot, Database } from "lucide-react";

export default function UserMenu() {
  const { currentUser, userInfo, logout } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Fonction de déconnexion
  async function handleLogout() {
    try {
      await logout();
      toast({
        title: "Déconnexion réussie",
        description: "Vous avez été déconnecté avec succès",
      });
    } catch (error) {
      toast({
        title: "Erreur de déconnexion",
        description: "Une erreur est survenue lors de la déconnexion",
        variant: "destructive",
      });
    }
  }

  // Si aucun utilisateur n'est connecté, afficher les boutons de connexion/inscription
  if (!currentUser) {
    return (
      <div className="flex gap-2">
        <Button 
          variant="outline" 
          onClick={() => navigate("/login")}
        >
          Connexion
        </Button>
        <Button 
          onClick={() => navigate("/register")}
        >
          Créer un compte
        </Button>
      </div>
    );
  }

  // Si un utilisateur est connecté, afficher le menu utilisateur
  const displayName = userInfo?.displayName || currentUser.displayName || currentUser.email;
  const initials = displayName ? displayName.substring(0, 2).toUpperCase() : "?";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative rounded-full h-10 w-10 p-0">
          <Avatar>
            <AvatarFallback className="bg-primary text-primary-foreground">
              {initials}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col">
            <span className="font-medium">{displayName}</span>
            <span className="text-xs text-gray-500 truncate">{currentUser.email}</span>
            <div className="mt-2 flex items-center">
              <Badge variant={userInfo?.plan === 'premium' ? "default" : "secondary"} className="flex items-center gap-1">
                {userInfo?.plan === 'premium' ? (
                  <>
                    <Sparkles className="h-3 w-3" />
                    Premium
                  </>
                ) : (
                  <>
                    Plan Gratuit
                  </>
                )}
              </Badge>
            </div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {/* Usage Stats */}
        <div className="px-2 py-1.5 text-xs">
          <div className="flex justify-between mb-1">
            <div className="flex items-center gap-1 text-muted-foreground">
              <BookText className="h-3 w-3" />
              Livres créés
            </div>
            <span>
              {userInfo?.booksCreated || 0} / {userInfo?.plan === 'premium' ? 'Illimité' : '3'}
            </span>
          </div>
          <div className="flex justify-between">
            <div className="flex items-center gap-1 text-muted-foreground">
              <Bot className="h-3 w-3" />
              Livres IA
            </div>
            <span>
              {userInfo?.aiBooksCreated || 0} / {userInfo?.plan === 'premium' ? 'Illimité' : '1'}
            </span>
          </div>
        </div>
        
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          className="cursor-pointer"
          onClick={() => navigate("/profile")}
        >
          <User className="mr-2 h-4 w-4" />
          <span>Profil</span>
        </DropdownMenuItem>
        <DropdownMenuItem 
          className="cursor-pointer"
          onClick={() => navigate("/settings")}
        >
          <Settings className="mr-2 h-4 w-4" />
          <span>Paramètres</span>
        </DropdownMenuItem>
        {/* Ajout de l'option Admin */}
        <DropdownMenuItem 
          className="cursor-pointer"
          onClick={() => navigate("/admin")}
        >
          <Database className="mr-2 h-4 w-4" />
          <span>Admin</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          className="cursor-pointer text-red-500 focus:text-red-500" 
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          <span>Déconnexion</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}